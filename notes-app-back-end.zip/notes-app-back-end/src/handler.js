const { nanoid } = require('nanoid');
const book = require('./book');

const addBookHandler = (request, h) => {
    const { name, year, author, summary, publisher, pageCount, readPage, reading} = request.payload;

    const id = nanoid(16);
    const finished = book.pageCount === book.readPage;
    const insertedAt = new Date().toISOString();
    const updateAt = createdAt;

    const newBook = {
        id, ...book, finished, insertedAt, updateAt,
    };

    book.push(newBook);

    if (!name) {
        const response = h.response({
          status: 'fail',
          message: 'Buku gagal ditambahkan, Tolong untuk mengisi nama Buku',
        });
        response.code(400);
        return response;
      }
     
      if (readPage > pageCount) {
        const response = h.response({
          status: 'fail',
          message: 'Buku gagal ditambahkan, readPage tidak boleh lebih besar dari pageCount'
      });
      response.code(400);
      return response;
    }
      const booksId = addBookHandler ({ name, year, author, summary, publisher, pageCount, readPage, reading});

      const response = h.response({
        status: 'succes',
        message: 'Buku berhasil ditambahkan',
        data: {
          booksId,
        },
      });
      response.code(201);
      return response;
};

const getAllBooksHandler = (h) => {
    book.map(({id, name, publisher}) => ({id, name, publisher}));

    const book = getAllBooksHandler();
    const response = h.response({
      status: 'success',
      data: {
        book,
      }
    });
    response.code(200);
    return response;
};

const getBookByIdHandler = (request, h) => {
  const getBookByIdHandler = (id) => book.find((book) => book.id === id);
  const {booksId} = request.params;
  const book = getBookByIdHandler(booksId);

  if(!book){
    const response = h.response({
      status: 'fail',
      message:'Buku tidak dapat ditemukan'
    });
    response.code(404);
    return response;
  }
  const response = h.response({
    status: 'success',
    data: {
      book,
    },
  });
  response.code(200);
  return response;
};

const editNoteByIdHandler = (request, h) => {
    const { id } = request.params;

    const { title, tags, body } = request.payload;
    const updatedAt = new Date().toISOString();

    const index = notes.findIndex((note) => note.id === id);

    if (index !== -1) {
        notes[index] = {
          ...notes[index],
          title,
          tags,
          body,
          updatedAt,
        };
     
        const response = h.response({
          status: 'success',
          message: 'Catatan berhasil diperbarui',
        });
        response.code(200);
        return response;
      }
     
      const response = h.response({
        status: 'fail',
        message: 'Gagal memperbarui catatan. Id tidak ditemukan',
      });
      response.code(404);
      return response;
};

const deleteNoteByIdHandler = (request, h) => {
    const { id } = request.params;

    const index = notes.findIndex((note) => note.id === id);

    if (index !== -1) {
        notes.splice(index, 1);
        const response = h.response({
          status: 'success',
          message: 'Catatan berhasil dihapus',
        });
        response.code(200);
        return response;
      }

      const response = h.response({
        status: 'fail',
        message: 'Catatan gagal dihapus. Id tidak ditemukan',
      });
      response.code(404);
      return response;
};

module.exports = { addBookHandler,
getAllBooksHandler, getBookByIdHandler,
    editNoteByIdHandler, deleteNoteByIdHandler };