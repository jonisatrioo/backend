const { addBookHandler, getAllBooksHandler, getBookByIdHandler, editNoteByIdHandler,
     deleteNoteByIdHandler } = require('./handler');

const routes = [
    {
      method: 'POST',
      path: '/book',
      handler: addBookHandler,
      options: {
        cors: {
          origin: ['*'],
        },
      },
    },
    
    {
        method: 'GET',
        path: '/book',
        handler: getAllBooksHandler,
    },

    {
        method: 'GET',
        path: '/book/{booksId}',
        handler: getBookByIdHandler,
      },

      {
        method: 'PUT',
        path: '/book/{id}',
        handler: editNoteByIdHandler,
      },

      {
        method: 'DELETE',
        path: '//{id}',
        handler: deleteNoteByIdHandler,
      },
   ];
    
   module.exports = routes;
